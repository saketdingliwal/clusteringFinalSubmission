import sys
import networkx as nx
from networkx.algorithms import isomorphism
import os
import numpy as np

train_data = sys.argv[1]
active_cat = sys.argv[2]
inactive_cat = sys.argv[3]
test_data = sys.argv[4]

base_supp = 0.05
max_feature = 100
prod_lim = 7500 * 400 * 400 


graphid_dict = {}
node_dict = {}
edge_dict = {}

inv_node_dict = []
inv_edge_dict = []

graph_list = []
active_list = []
inactive_list = []
train_list =[]
test_list = []



with open(train_data,'r') as train_f:
	lines = train_f.readlines()

curr_line = 0
while curr_line<len(lines):
	line = lines[curr_line]
	graphid = line[1:-1]
	train_list.append(len(graphid_dict.keys()))
	graphid_dict[graphid] = len(graphid_dict.keys())
	curr_line+=1
	n = int(lines[curr_line].split()[0])
	curr_line+=1
	node_list = []
	edge_list = []
	for i in range(n):
		node_label = lines[curr_line].split()[0]
		if node_label not in node_dict:
			inv_node_dict.append(node_label)
			node_dict[node_label] = len(node_dict.keys())
		node_label_int = node_dict[node_label]
		node_list.append(node_label_int)
		curr_line+=1
	m = int(lines[curr_line].split()[0])
	curr_line+=1
	for i in range(m):
		line = lines[curr_line].split()
		src = int(line[0])
		dest = int(line[1])
		edge_label = line[2]
		if edge_label not in edge_dict:
			inv_edge_dict.append(edge_label)
			edge_dict[edge_label] = len(edge_dict.keys())
		edge_label_int = edge_dict[edge_label]
		edge_list.append((src,dest,edge_label_int))
		curr_line+=1
	graph_list.append((node_list,edge_list))


with open(test_data,'r') as test_f:
	lines = test_f.readlines()

curr_line = 0
while curr_line<len(lines):
	line = lines[curr_line]
	graphid = line[1:-1] + "_test"
	test_list.append(len(graphid_dict.keys()))
	graphid_dict[graphid] = len(graphid_dict.keys())
	curr_line+=1
	n = int(lines[curr_line].split()[0])
	curr_line+=1
	node_list = []
	edge_list = []
	for i in range(n):
		node_label = lines[curr_line].split()[0]
		if node_label not in node_dict:
			inv_node_dict.append(node_label)
			node_dict[node_label] = len(node_dict.keys())
		node_label_int = node_dict[node_label]
		node_list.append(node_label_int)
		curr_line+=1
	m = int(lines[curr_line].split()[0])
	curr_line+=1
	for i in range(m):
		line = lines[curr_line].split()
		src = int(line[0])
		dest = int(line[1])
		edge_label = line[2]
		if edge_label not in edge_dict:
			inv_edge_dict.append(edge_label)
			edge_dict[edge_label] = len(edge_dict.keys())
		edge_label_int = edge_dict[edge_label]
		edge_list.append((src,dest,edge_label_int))
		curr_line+=1
	graph_list.append((node_list,edge_list))


max_feature = max(1,min(100,((700*1200)//len(test_list))))

with open(active_cat,'r') as active_ids:
	lines = active_ids.readlines()
for line in lines:
	active_id = line.split()[0]
	if active_id in graphid_dict:
		active_list.append(graphid_dict[active_id])


with open(inactive_cat,'r') as inactive_ids:
	lines = inactive_ids.readlines()
for line in lines:
	inactive_id = line.split()[0]
	if inactive_id in graphid_dict:
		inactive_list.append(graphid_dict[inactive_id])

np.random.shuffle(active_list)
np.random.shuffle(inactive_list)

minn_len = min(min(len(inactive_list),len(active_list)),7500)
active_len_act = len(active_list)
inactive_len_act = len(inactive_list)
active_list = active_list[:minn_len]
inactive_list = inactive_list[:minn_len]


def convert_list(given_list,filename):
	out = open(filename,'w')
	for graph_int in given_list:
		out.write("t # " + str(graph_int) + "\n")
		node_list = graph_list[graph_int][0]
		edge_list = graph_list[graph_int][1]
		node_count = 0
		for node in node_list:
			out.write("v " + str(node_count) + " " + str(node) + "\n")
			node_count+=1
		for edge in edge_list:
			out.write("e " + str(edge[0]) + " " + str(edge[1]) + " " + str(edge[2]) + "\n")
	out.close()



combined_list  = active_list + inactive_list
combined_file = "combined"
combined_file_out = combined_file + ".fp"


convert_list(combined_list,combined_file)


cmd = "./gSpan -f " + combined_file + " -s " + str(base_supp) + " -o -i"
os.system(cmd)

with open(combined_file_out,'r') as data_out:
	lines = data_out.readlines()


active_len = len(active_list)
inactive_len = len(inactive_list)

active_mat_t = []
inactive_mat_t = []

sub_graph_list = []
curr_line = 0
while curr_line < len(lines):
	try:
		line = lines[curr_line]
		sub_support = line.split()[4]
		graphid = line.split()[2]
		curr_line+=1
		line = lines[curr_line]
		node_labels = []
		edge_labels = []
		id_list = []
		while line[0]=='v':
			node_labels.append(int(line.split()[2]))
			curr_line+=1
			line = lines[curr_line]
		while line[0]=='e':
			edge_labels.append((int(line.split()[1]),int(line.split()[2]),int(line.split()[3])))
			curr_line+=1
			line = lines[curr_line]
		elem_active = [0] * active_len
		elem_inactive = [0] * inactive_len
		ind_lis = line.split()[1:]
		for ind in ind_lis:
			ind_int = int(ind)
			if ind_int < active_len:
				elem_active[ind_int] = 1
			else:
				elem_inactive[ind_int - active_len] = 1
		sub_graph_list.append((node_labels,edge_labels))
		active_mat_t.append(elem_active) 
		inactive_mat_t.append(elem_inactive) 
		curr_line+=2
	except:
		break


active_mat = np.transpose(active_mat_t)
inactive_mat = np.transpose(inactive_mat_t)


na = np.sum(active_mat,axis=0)
ni = np.sum(inactive_mat,axis=0)
ua = np.mean(active_mat,axis=0)
ui = np.mean(inactive_mat,axis=0)

sa = np.std(active_mat,axis=0)
si = np.std(inactive_mat,axis=0)

u = (na + ni)/(active_len+inactive_len)

ua_u = ua-u
ui_u = ui-u
numa = np.multiply(na,np.multiply(ua_u,ua_u))
numi = np.multiply(ni,np.multiply(ui_u,ui_u))
num = numa + numi
dena = np.multiply(na,np.multiply(sa,sa))
deni = np.multiply(ni,np.multiply(si,si))
den = dena + deni

fis_score = np.divide(num,den, out=np.zeros_like(num), where=den!=0)
prod = len(fis_score) * len(fis_score) * 2 * active_len
curr_feat = set()
# if prod > prod_lim:
if True:
	new_feat = np.argsort(fis_score)[(-1*max_feature):][::-1]
	print("tight case")	
	for ind in new_feat:
		curr_feat.add(ind)
		# print (na[ind],ni[ind],numa[ind],numi[ind])
else:
	r_mat = []
	for i in range(len(fis_score)):
		elem = []
		feat_i_col_a  = active_mat_t[i]
		feat_i_col_i  = inactive_mat_t[i]
		p_i = na[i] + ni[i]
		for j in range(len(fis_score)):
			p_j = na[j] + ni[j]
			feat_j_col_a  = active_mat_t[j]
			feat_j_col_i  = inactive_mat_t[j]
			a_i_j = np.dot(feat_j_col_a,feat_i_col_a)
			i_i_j = np.dot(feat_j_col_i,feat_i_col_i)
			p_i_j = a_i_j + i_i_j
			r_i_j = (p_i_j/(p_i + p_j - p_i_j))*(min(fis_score[i],fis_score[j]))
			elem.append(r_i_j)
		maxx = np.argmin(elem)
		r_mat.append(elem)

	maxx = np.argmax(fis_score)
	curr_feat.add(maxx)
	not_feat = set()
	maxx_r = []
	for i in range(len(fis_score)):
		maxx_r.append(r_mat[i][maxx])
		if not i == maxx:
			not_feat.add(i)

	iterr = 1
	while len(not_feat) > 0:
		i_g = fis_score - maxx_r
		ig_maxx = np.argmax(i_g)
		if i_g[ig_maxx] <=0:
			break
		if ig_maxx in not_feat: 
			not_feat.remove(ig_maxx)
		curr_feat.add(ig_maxx)
		iterr+=1
		if iterr > max_feature:
			break
		for i in range(len(fis_score)):
			maxx_r[i] = max(maxx_r[i],r_mat[i][ig_maxx])
	

num_feat = len(curr_feat)

active_mat_t_new = []
inactive_mat_t_new = []

for feature in curr_feat:
	active_mat_t_new.append(active_mat_t[feature])
	inactive_mat_t_new.append(inactive_mat_t[feature])

active_mat_new = np.transpose(active_mat_t_new)
inactive_mat_new = np.transpose(inactive_mat_t_new)


train_out = "train.txt"
train_f = open(train_out,'w')

 
for i in range(active_len_act):
	train_f.write("1 ")
	for j in range(num_feat):
		train_f.write(str(j) + ":" + str(active_mat_new[i%active_len][j]) + " ")
	train_f.write("\n")

for i in range(inactive_len_act):
	train_f.write("-1 ")
	for j in range(num_feat):
		train_f.write(str(j) + ":" + str(inactive_mat_new[i%inactive_len][j]) + " ")
	train_f.write("\n")



def make_graph(node_list,edge_list):
	G = nx.Graph()
	for node_no,node in enumerate(node_list):
		G.add_node(node_no,node_label=node)
	for edge in edge_list:
		G.add_edge(edge[0],edge[1],edge_label=edge[2])
	return G

sub_graph_list_new = []
for feature in curr_feat:
	sub_graph_list_new.append(make_graph(sub_graph_list[feature][0],sub_graph_list[feature][1]))
sub_graph_list = sub_graph_list_new


def node_match(node1,node2):
	if (node1["node_label"]==node2["node_label"]):
		return True
	return False
def edge_match(edge1,edge2):
	if (edge1["edge_label"]==edge2["edge_label"]):
		return True
	return False

def make_vector(graph_id):
	bin_vect = []
	big = make_graph(graph_list[graph_id][0],graph_list[graph_id][1])
	for sub in sub_graph_list:
		GM = isomorphism.GraphMatcher(big,sub,node_match,edge_match)
		bit = GM.subgraph_is_isomorphic()
		bin_vect.append(int(bit))
	return bin_vect


test_out  = "test.txt"
test_f = open(test_out,'w')
for test_id in test_list:
	vector = make_vector(test_id)
	for i in range(len(vector)):
		test_f.write(str(i) + ":" + str(vector[i]) + " ")
	test_f.write("\n")

train_f.close()
test_f.close()