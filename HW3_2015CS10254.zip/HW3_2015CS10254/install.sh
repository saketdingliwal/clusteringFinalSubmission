git clone https://github.com/saketdingliwal/clusteringFinalSubmission.git
pip install networkx
pip install numpy