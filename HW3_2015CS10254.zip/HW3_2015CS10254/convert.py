import sys

file_name = sys.argv[1]
out_file = sys.argv[2]

with open(file_name,'r') as fp:
	lines = fp.readlines()


out = open(out_file,'w')

node_dict = {}
edge_dict = {}
graph_id = 0
curr_line = 0
while curr_line<len(lines):
	out.write("t # " + str(graph_id) + "\n")
	graph_id+=1
	curr_line+=1
	n = int(lines[curr_line].split()[0])
	curr_line+=1
	for i in range(n):
		node_label = lines[curr_line].split()[0]
		if node_label not in node_dict:
			node_dict[node_label] = len(node_dict.keys())
		node_label_int = node_dict[node_label]
		out.write("v " + str(i) + " " + str(node_label_int) + "\n")
		curr_line+=1
	m = int(lines[curr_line].split()[0])
	curr_line+=1
	for i in range(m):
		line = lines[curr_line].split()
		src = line[0]
		dest = line[1]
		edge_label = line[2]
		if edge_label not in edge_dict:
			edge_dict[edge_label] = len(edge_dict.keys())
		edge_label_int = edge_dict[edge_label]
		out.write("e " + src + " " + dest + " " + str(edge_label_int) + "\n")
		curr_line+=1

out.close()