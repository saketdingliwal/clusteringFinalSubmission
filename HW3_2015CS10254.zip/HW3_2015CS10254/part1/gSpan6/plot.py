import sys
import os
import time, subprocess                                


file_name = sys.argv[1]
data_file = sys.argv[2]

support_arr = [0.95,0.5,0.25,0.1,0.05]
f = open(data_file,'w')
for support in support_arr:
	timeStarted = time.time()
	arg_list = ['./gSpan','-f ' + file_name, '-s ' + str(support)]
	cmd = (' '.join(arg_list))
	os.system(cmd)
	timeDelta = time.time() - timeStarted
	f.write(str(support) + ";" + str(round(timeDelta,2)) + "\n")
f.close()