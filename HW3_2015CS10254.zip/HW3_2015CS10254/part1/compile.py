import matplotlib.pyplot as plt

def read_file(filename):
	with open(filename) as df:
		lines = df.readlines()
	times = []
	for line in lines:
		times.append(float(line.split(";")[1].split()[0]))
	return times

supp = [0.95,0.5,0.25,0.1,0.05]

vals = [2,44,210,1157,4353]

gspan  = read_file("gSpan.csv")
fsg  = read_file("fsg.csv")
gaston  = read_file("gaston.csv")
plt.plot(supp, gspan, 'r--')
plt.plot(supp, gspan, 'rs', label='gspan')
plt.plot(supp, fsg, 'b--')
plt.plot(supp, fsg, 'bs', label='fsg')
plt.plot(supp, gaston, 'g--')
plt.plot(supp, gaston, 'gs', label='gaston')
plt.legend()
plt.xlabel('support threshold ')
plt.ylabel('time taken [in s] ')
plt.savefig('part1.png')